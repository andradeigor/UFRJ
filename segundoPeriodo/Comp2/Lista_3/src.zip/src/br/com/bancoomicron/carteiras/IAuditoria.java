/*
Nome: Igor de Andrade Assunção de Almeida
DRE:121095736
*/

package br.com.bancoomicron.carteiras;

public interface IAuditoria {
    double somaSaldo();
    int quantidadeContas();
}
