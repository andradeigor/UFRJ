package br.com.bancoomicron.carteiras;
/*
Nome: Igor de Andrade Assunção de Almeida
DRE:121095736
*/
public interface IAuditoria {
    double somaSaldo();
    int quantidadeContas();
}
